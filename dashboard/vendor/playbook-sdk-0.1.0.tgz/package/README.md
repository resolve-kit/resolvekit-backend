# @playbook/sdk

Embed an AI chat assistant into any web app with a single `init()` call — styled after Intercom. The assistant can call your JavaScript functions, navigate pages, fetch data, and highlight DOM elements to guide users.

## Quick start

### CDN (30 seconds)

```html
<script src="https://cdn.playbook.ai/sdk/latest/sdk.min.js"></script>
<script>
  window.PlaybookSDK.init({ apiKey: 'iaa_your_key_here' })
</script>
```

### npm

```bash
npm install @playbook/sdk
```

```ts
import PlaybookSDK, { fn } from '@playbook/sdk'

PlaybookSDK.init({
  auth: { mode: 'apiKey', apiKey: 'iaa_your_key_here' },
  functions: [
    fn(navigateTo, {
      description: 'Navigate the user to a page in the app',
      parameters: {
        path: { type: 'string', description: 'Route path, e.g. /settings or /dashboard' },
      },
    }),
    fn(fetchOrders, {
      description: 'Fetch the user's recent orders',
      parameters: {
        limit: { type: 'number', description: 'Max number of orders to return' },
      },
    }),
    fn(applyPromoCode, {
      description: 'Apply a promo code to the current cart',
      parameters: {
        code: { type: 'string', description: 'The promo code string' },
      },
    }),
  ],
})
```



## Token Provider Auth (recommended for dashboards)

```ts
PlaybookSDK.init({
  auth: {
    mode: 'tokenProvider',
    getToken: async ({ appId }) => {
      const res = await fetch('/v1/copilot/runtime-token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ app_id: appId }),
      })
      const payload = await res.json()
      return { token: payload.runtime_token, expiresAt: payload.expires_at }
    },
  },
  appId: 'current-app-id',
  functions: [],
})

PlaybookSDK.setAppContext({ appId: 'new-app-id' })
```

## Element outlining

Add `data-playbook-id` to elements you want the AI to be able to highlight:

```html
<button data-playbook-id="submit-order">Submit Order</button>
<section data-playbook-id="pricing-table">Pricing</section>
<nav data-playbook-id="main-nav">Navigation</nav>
```

The AI automatically has access to `highlight_element` and `clear_highlights` — no extra registration needed.

## React / Next.js

```tsx
// app/layout.tsx (Next.js App Router) or _app.tsx
import { PlaybookProvider } from '@playbook/sdk/react'
import { fn } from '@playbook/sdk'

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <PlaybookProvider
          apiKey={process.env.NEXT_PUBLIC_PLAYBOOK_KEY!}
          functions={[
            fn(navigate, {
              description: 'Navigate to a dashboard page',
              parameters: { path: { type: 'string', description: 'Route path' } },
            }),
          ]}
        >
          {children}
        </PlaybookProvider>
      </body>
    </html>
  )
}
```

Access state from any component:

```tsx
import { usePlaybook } from '@playbook/sdk/react'

function Header() {
  const { open, state } = usePlaybook()
  return (
    <button onClick={open}>
      Chat {state.messages.length > 0 && `(${state.messages.length})`}
    </button>
  )
}
```

## Programmatic control

```ts
PlaybookSDK.open()       // open the chat panel
PlaybookSDK.close()      // close it
PlaybookSDK.destroy()    // tear down completely

PlaybookSDK.on('statechange', (state) => console.log(state))
PlaybookSDK.on('message', (msg) => console.log(msg.content))
PlaybookSDK.on('toolcall', (call) => console.log(call.functionName))
```

## Documentation

- [API Reference](docs/api-reference.md) — complete public API
- [Integration Guide](docs/integration-guide.md) — step-by-step Next.js walkthrough
- [Function Authoring](docs/function-authoring.md) — how to write and register functions
- [Element Outlining](docs/element-outlining.md) — `data-playbook-id` reference
- [llms.txt](llms.txt) — machine-optimized guide for AI coding assistants


## Helper packages

- `@playbook/sdk/react-router` — route helper functions (`createRouterFunctions`).
- `@playbook/sdk/starter` — onboarding helpers (`createOnboardingFunctions`, `validatePlaybookIds`).
